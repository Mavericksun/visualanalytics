404 stránka
===========
:slug: 404
:lang: cz
:status: hidden

Jednoduchá 404 stránka.
