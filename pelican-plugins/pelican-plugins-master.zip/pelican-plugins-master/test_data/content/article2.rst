Second article
##############

:tags: foo, bar, baz
:date: 2012-02-29
:lang: en
:slug: second-article

This is some article, in english
