# -*- coding: utf-8 -*-
__title__ = 'bootstrap-rst'
__version__ = '0.1.1'
__author__ = 'Nicolas P. Rougier'
__credits__ = ['Nicolas P. Rougier', 'Alex Waite', 'Trevor Morgan']
__maintainer__ = "Alex Waite"
__email__ = "alex@waite.eu"
__status__ = "Development"
__license__ = 'MIT'
__copyright__ = 'Copyright 2014'

from .bootstrap import *
