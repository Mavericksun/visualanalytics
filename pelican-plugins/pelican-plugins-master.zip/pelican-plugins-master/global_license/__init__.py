from .global_license import *
