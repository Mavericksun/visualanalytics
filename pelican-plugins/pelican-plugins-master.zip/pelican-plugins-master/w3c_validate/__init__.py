# -*- coding: utf-8 -*-
from .wc3_validate import *
