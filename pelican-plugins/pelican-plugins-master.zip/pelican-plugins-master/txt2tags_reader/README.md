# txt2tags_reader
A [txt2tags] reader plugin for the [Pelican static site generator](http://docs.getpelican.com/en/latest/).

Requirements
------------
[txt2tags] in $PATH

Installation
------------
Instructions on installing pelican plugins can be found in the [pelican plugin manual](https://github.com/getpelican/pelican-plugins/blob/master/Readme.rst).

[txt2tags]:http://txt2tags.org/
