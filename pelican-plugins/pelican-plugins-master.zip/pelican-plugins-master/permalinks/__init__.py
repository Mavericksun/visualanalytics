from .permalinks import register
